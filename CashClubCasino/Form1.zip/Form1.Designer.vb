﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Controller = New System.Windows.Forms.TabControl()
        Me.StartPage = New System.Windows.Forms.TabPage()
        Me.LoginMenuPanel = New System.Windows.Forms.TableLayoutPanel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.LoginMenu_QuitBtn = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.LoginMenu_NameTxt = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.LoginMenu_AgeNum = New System.Windows.Forms.NumericUpDown()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.LoginMenu_plus1000Btn = New System.Windows.Forms.Button()
        Me.LoginMenu_plus100Btn = New System.Windows.Forms.Button()
        Me.LoginMenu_min100Btn = New System.Windows.Forms.Button()
        Me.LoginMenu_min1000Btn = New System.Windows.Forms.Button()
        Me.LoginMenu_CapitalLbl = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.LoginMenu_LoginBtn = New System.Windows.Forms.Button()
        Me.BombSearchPage = New System.Windows.Forms.TabPage()
        Me.GameLayout_Nav = New System.Windows.Forms.TableLayoutPanel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.GameLayout_BalanceLbl_BombSearch = New System.Windows.Forms.Label()
        Me.GameLayout_UsernameLbl_BombSearch = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.GameLayout_Panel = New System.Windows.Forms.TableLayoutPanel()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.GameSelector_BombSearch = New System.Windows.Forms.GroupBox()
        Me.GameLayout_Selector_Slots = New System.Windows.Forms.RadioButton()
        Me.GameLayout_Selector_BlackJack = New System.Windows.Forms.RadioButton()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GameLayout_Selector_Self_BombSearch = New System.Windows.Forms.RadioButton()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.LogoutBtn_BombSearch = New System.Windows.Forms.Button()
        Me.BlackJackPage = New System.Windows.Forms.TabPage()
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.GameLayout_BalanceLbl_BlackJack = New System.Windows.Forms.Label()
        Me.GameLayout_UsernameLbl_BlackJack = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel5 = New System.Windows.Forms.TableLayoutPanel()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.GameSelector_BlackJack = New System.Windows.Forms.GroupBox()
        Me.GameLayout_Selector_SlotMachines_BlackJack = New System.Windows.Forms.RadioButton()
        Me.GameLayout_Selector_Self_BlackJack = New System.Windows.Forms.RadioButton()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.GameLayout_Selector_BombSearch_BlackJack = New System.Windows.Forms.RadioButton()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.LogoutBtn_BlackJack = New System.Windows.Forms.Button()
        Me.SlotMachinesPage = New System.Windows.Forms.TabPage()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.GameLayout_BalanceLbl_SlotMachines = New System.Windows.Forms.Label()
        Me.GameLayout_UsernameLbl_SlotMachines = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.GameSelector_SlotMachines = New System.Windows.Forms.GroupBox()
        Me.GameLayout_Selector_Self_SlotMachines = New System.Windows.Forms.RadioButton()
        Me.GameLayout_Selector_BlackJack_SlotMachines = New System.Windows.Forms.RadioButton()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.GameLayout_Selector_BombSearch_SlotMachines = New System.Windows.Forms.RadioButton()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.LogoutBtn_SlotMachines = New System.Windows.Forms.Button()
        Me.Controller.SuspendLayout()
        Me.StartPage.SuspendLayout()
        Me.LoginMenuPanel.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LoginMenu_AgeNum, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.BombSearchPage.SuspendLayout()
        Me.GameLayout_Nav.SuspendLayout()
        Me.GameLayout_Panel.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GameSelector_BombSearch.SuspendLayout()
        Me.BlackJackPage.SuspendLayout()
        Me.TableLayoutPanel4.SuspendLayout()
        Me.TableLayoutPanel5.SuspendLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GameSelector_BlackJack.SuspendLayout()
        Me.SlotMachinesPage.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.TableLayoutPanel3.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GameSelector_SlotMachines.SuspendLayout()
        Me.SuspendLayout()
        '
        'Controller
        '
        Me.Controller.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Controller.Controls.Add(Me.StartPage)
        Me.Controller.Controls.Add(Me.BombSearchPage)
        Me.Controller.Controls.Add(Me.BlackJackPage)
        Me.Controller.Controls.Add(Me.SlotMachinesPage)
        Me.Controller.Location = New System.Drawing.Point(0, -20)
        Me.Controller.Name = "Controller"
        Me.Controller.SelectedIndex = 0
        Me.Controller.Size = New System.Drawing.Size(1280, 706)
        Me.Controller.TabIndex = 0
        '
        'StartPage
        '
        Me.StartPage.BackgroundImage = Global.CashClubCasino.My.Resources.Resources._679edc0bd89fc0b1cca71c70ceb7aed3e47bc8b5
        Me.StartPage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.StartPage.Controls.Add(Me.LoginMenuPanel)
        Me.StartPage.Location = New System.Drawing.Point(4, 22)
        Me.StartPage.Name = "StartPage"
        Me.StartPage.Size = New System.Drawing.Size(1272, 680)
        Me.StartPage.TabIndex = 0
        Me.StartPage.Text = "TabPage3"
        Me.StartPage.UseVisualStyleBackColor = True
        '
        'LoginMenuPanel
        '
        Me.LoginMenuPanel.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.LoginMenuPanel.BackColor = System.Drawing.Color.Transparent
        Me.LoginMenuPanel.BackgroundImage = Global.CashClubCasino.My.Resources.Resources.dark_overlay
        Me.LoginMenuPanel.ColumnCount = 3
        Me.LoginMenuPanel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.30221!))
        Me.LoginMenuPanel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 88.69779!))
        Me.LoginMenuPanel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60.0!))
        Me.LoginMenuPanel.Controls.Add(Me.PictureBox1, 1, 0)
        Me.LoginMenuPanel.Controls.Add(Me.LoginMenu_QuitBtn, 1, 8)
        Me.LoginMenuPanel.Controls.Add(Me.Label1, 1, 3)
        Me.LoginMenuPanel.Controls.Add(Me.LoginMenu_NameTxt, 1, 2)
        Me.LoginMenuPanel.Controls.Add(Me.Label2, 1, 1)
        Me.LoginMenuPanel.Controls.Add(Me.LoginMenu_AgeNum, 1, 4)
        Me.LoginMenuPanel.Controls.Add(Me.TableLayoutPanel1, 1, 6)
        Me.LoginMenuPanel.Controls.Add(Me.Label4, 1, 5)
        Me.LoginMenuPanel.Controls.Add(Me.LoginMenu_LoginBtn, 1, 7)
        Me.LoginMenuPanel.Location = New System.Drawing.Point(422, -3)
        Me.LoginMenuPanel.Name = "LoginMenuPanel"
        Me.LoginMenuPanel.RowCount = 10
        Me.LoginMenuPanel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80.92486!))
        Me.LoginMenuPanel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.07514!))
        Me.LoginMenuPanel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60.0!))
        Me.LoginMenuPanel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 49.0!))
        Me.LoginMenuPanel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 46.0!))
        Me.LoginMenuPanel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 47.0!))
        Me.LoginMenuPanel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 48.0!))
        Me.LoginMenuPanel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 85.0!))
        Me.LoginMenuPanel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 63.0!))
        Me.LoginMenuPanel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 22.0!))
        Me.LoginMenuPanel.Size = New System.Drawing.Size(429, 687)
        Me.LoginMenuPanel.TabIndex = 1
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImage = Global.CashClubCasino.My.Resources.Resources.image_removebg_preview
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox1.Location = New System.Drawing.Point(44, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(321, 210)
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'LoginMenu_QuitBtn
        '
        Me.LoginMenu_QuitBtn.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.LoginMenu_QuitBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LoginMenu_QuitBtn.Font = New System.Drawing.Font("Segoe UI", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LoginMenu_QuitBtn.Location = New System.Drawing.Point(44, 604)
        Me.LoginMenu_QuitBtn.Name = "LoginMenu_QuitBtn"
        Me.LoginMenu_QuitBtn.Size = New System.Drawing.Size(321, 57)
        Me.LoginMenu_QuitBtn.TabIndex = 1
        Me.LoginMenu_QuitBtn.Text = "Quit"
        Me.LoginMenu_QuitBtn.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label1.Location = New System.Drawing.Point(96, 338)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(217, 37)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Select Your Age"
        '
        'LoginMenu_NameTxt
        '
        Me.LoginMenu_NameTxt.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.LoginMenu_NameTxt.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LoginMenu_NameTxt.Location = New System.Drawing.Point(44, 269)
        Me.LoginMenu_NameTxt.Name = "LoginMenu_NameTxt"
        Me.LoginMenu_NameTxt.Size = New System.Drawing.Size(321, 35)
        Me.LoginMenu_NameTxt.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label2.Location = New System.Drawing.Point(56, 229)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(297, 37)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Enter Your User Name"
        '
        'LoginMenu_AgeNum
        '
        Me.LoginMenu_AgeNum.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.LoginMenu_AgeNum.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LoginMenu_AgeNum.Location = New System.Drawing.Point(44, 378)
        Me.LoginMenu_AgeNum.Name = "LoginMenu_AgeNum"
        Me.LoginMenu_AgeNum.Size = New System.Drawing.Size(321, 35)
        Me.LoginMenu_AgeNum.TabIndex = 8
        Me.LoginMenu_AgeNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.ColumnCount = 5
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55.31915!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 44.68085!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 105.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 67.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.LoginMenu_plus1000Btn, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.LoginMenu_plus100Btn, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.LoginMenu_min100Btn, 3, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.LoginMenu_min1000Btn, 4, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.LoginMenu_CapitalLbl, 2, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(44, 471)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 42.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(321, 42)
        Me.TableLayoutPanel1.TabIndex = 9
        '
        'LoginMenu_plus1000Btn
        '
        Me.LoginMenu_plus1000Btn.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LoginMenu_plus1000Btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LoginMenu_plus1000Btn.Location = New System.Drawing.Point(3, 3)
        Me.LoginMenu_plus1000Btn.Name = "LoginMenu_plus1000Btn"
        Me.LoginMenu_plus1000Btn.Size = New System.Drawing.Size(48, 36)
        Me.LoginMenu_plus1000Btn.TabIndex = 0
        Me.LoginMenu_plus1000Btn.Text = "+1000"
        Me.LoginMenu_plus1000Btn.UseVisualStyleBackColor = True
        '
        'LoginMenu_plus100Btn
        '
        Me.LoginMenu_plus100Btn.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LoginMenu_plus100Btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LoginMenu_plus100Btn.Location = New System.Drawing.Point(57, 3)
        Me.LoginMenu_plus100Btn.Name = "LoginMenu_plus100Btn"
        Me.LoginMenu_plus100Btn.Size = New System.Drawing.Size(38, 36)
        Me.LoginMenu_plus100Btn.TabIndex = 1
        Me.LoginMenu_plus100Btn.Text = "+100"
        Me.LoginMenu_plus100Btn.UseVisualStyleBackColor = True
        '
        'LoginMenu_min100Btn
        '
        Me.LoginMenu_min100Btn.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LoginMenu_min100Btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LoginMenu_min100Btn.Location = New System.Drawing.Point(206, 3)
        Me.LoginMenu_min100Btn.Name = "LoginMenu_min100Btn"
        Me.LoginMenu_min100Btn.Size = New System.Drawing.Size(44, 36)
        Me.LoginMenu_min100Btn.TabIndex = 2
        Me.LoginMenu_min100Btn.Text = "-100"
        Me.LoginMenu_min100Btn.UseVisualStyleBackColor = True
        '
        'LoginMenu_min1000Btn
        '
        Me.LoginMenu_min1000Btn.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LoginMenu_min1000Btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LoginMenu_min1000Btn.Location = New System.Drawing.Point(256, 3)
        Me.LoginMenu_min1000Btn.Name = "LoginMenu_min1000Btn"
        Me.LoginMenu_min1000Btn.Size = New System.Drawing.Size(62, 36)
        Me.LoginMenu_min1000Btn.TabIndex = 3
        Me.LoginMenu_min1000Btn.Text = "-1000"
        Me.LoginMenu_min1000Btn.UseVisualStyleBackColor = True
        '
        'LoginMenu_CapitalLbl
        '
        Me.LoginMenu_CapitalLbl.AutoSize = True
        Me.LoginMenu_CapitalLbl.BackColor = System.Drawing.Color.White
        Me.LoginMenu_CapitalLbl.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LoginMenu_CapitalLbl.ForeColor = System.Drawing.SystemColors.ControlText
        Me.LoginMenu_CapitalLbl.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.LoginMenu_CapitalLbl.Location = New System.Drawing.Point(102, 4)
        Me.LoginMenu_CapitalLbl.Margin = New System.Windows.Forms.Padding(4)
        Me.LoginMenu_CapitalLbl.Name = "LoginMenu_CapitalLbl"
        Me.LoginMenu_CapitalLbl.Size = New System.Drawing.Size(97, 34)
        Me.LoginMenu_CapitalLbl.TabIndex = 4
        Me.LoginMenu_CapitalLbl.Text = "0$"
        Me.LoginMenu_CapitalLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label4.Location = New System.Drawing.Point(91, 431)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(226, 37)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Starting  Capital"
        '
        'LoginMenu_LoginBtn
        '
        Me.LoginMenu_LoginBtn.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.LoginMenu_LoginBtn.BackColor = System.Drawing.Color.White
        Me.LoginMenu_LoginBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LoginMenu_LoginBtn.Font = New System.Drawing.Font("Segoe UI", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LoginMenu_LoginBtn.Location = New System.Drawing.Point(44, 540)
        Me.LoginMenu_LoginBtn.Name = "LoginMenu_LoginBtn"
        Me.LoginMenu_LoginBtn.Size = New System.Drawing.Size(321, 58)
        Me.LoginMenu_LoginBtn.TabIndex = 0
        Me.LoginMenu_LoginBtn.Text = "Login"
        Me.LoginMenu_LoginBtn.UseVisualStyleBackColor = False
        '
        'BombSearchPage
        '
        Me.BombSearchPage.BackgroundImage = Global.CashClubCasino.My.Resources.Resources.casino_bg
        Me.BombSearchPage.Controls.Add(Me.GameLayout_Nav)
        Me.BombSearchPage.Controls.Add(Me.GameLayout_Panel)
        Me.BombSearchPage.Location = New System.Drawing.Point(4, 22)
        Me.BombSearchPage.Name = "BombSearchPage"
        Me.BombSearchPage.Size = New System.Drawing.Size(1272, 680)
        Me.BombSearchPage.TabIndex = 1
        Me.BombSearchPage.Text = "TabPage3"
        Me.BombSearchPage.UseVisualStyleBackColor = True
        '
        'GameLayout_Nav
        '
        Me.GameLayout_Nav.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GameLayout_Nav.BackColor = System.Drawing.Color.Transparent
        Me.GameLayout_Nav.BackgroundImage = Global.CashClubCasino.My.Resources.Resources.dark_overlay
        Me.GameLayout_Nav.ColumnCount = 5
        Me.GameLayout_Nav.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 62.08252!))
        Me.GameLayout_Nav.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 37.91748!))
        Me.GameLayout_Nav.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 132.0!))
        Me.GameLayout_Nav.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 126.0!))
        Me.GameLayout_Nav.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 143.0!))
        Me.GameLayout_Nav.Controls.Add(Me.Label5, 3, 0)
        Me.GameLayout_Nav.Controls.Add(Me.GameLayout_BalanceLbl_BombSearch, 4, 0)
        Me.GameLayout_Nav.Controls.Add(Me.GameLayout_UsernameLbl_BombSearch, 0, 0)
        Me.GameLayout_Nav.Controls.Add(Me.Label8, 1, 0)
        Me.GameLayout_Nav.Location = New System.Drawing.Point(247, -3)
        Me.GameLayout_Nav.Margin = New System.Windows.Forms.Padding(0)
        Me.GameLayout_Nav.Name = "GameLayout_Nav"
        Me.GameLayout_Nav.RowCount = 1
        Me.GameLayout_Nav.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.GameLayout_Nav.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.GameLayout_Nav.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.GameLayout_Nav.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.GameLayout_Nav.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.GameLayout_Nav.Size = New System.Drawing.Size(1021, 50)
        Me.GameLayout_Nav.TabIndex = 5
        '
        'Label5
        '
        Me.Label5.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI Semibold", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label5.Location = New System.Drawing.Point(780, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(94, 50)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Balance:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GameLayout_BalanceLbl_BombSearch
        '
        Me.GameLayout_BalanceLbl_BombSearch.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.GameLayout_BalanceLbl_BombSearch.AutoSize = True
        Me.GameLayout_BalanceLbl_BombSearch.Font = New System.Drawing.Font("Segoe UI Semibold", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GameLayout_BalanceLbl_BombSearch.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GameLayout_BalanceLbl_BombSearch.Location = New System.Drawing.Point(880, 0)
        Me.GameLayout_BalanceLbl_BombSearch.Name = "GameLayout_BalanceLbl_BombSearch"
        Me.GameLayout_BalanceLbl_BombSearch.Size = New System.Drawing.Size(66, 50)
        Me.GameLayout_BalanceLbl_BombSearch.TabIndex = 1
        Me.GameLayout_BalanceLbl_BombSearch.Text = "0.00$"
        Me.GameLayout_BalanceLbl_BombSearch.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'GameLayout_UsernameLbl_BombSearch
        '
        Me.GameLayout_UsernameLbl_BombSearch.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.GameLayout_UsernameLbl_BombSearch.AutoSize = True
        Me.GameLayout_UsernameLbl_BombSearch.Font = New System.Drawing.Font("Segoe UI Semibold", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GameLayout_UsernameLbl_BombSearch.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GameLayout_UsernameLbl_BombSearch.Location = New System.Drawing.Point(3, 0)
        Me.GameLayout_UsernameLbl_BombSearch.Name = "GameLayout_UsernameLbl_BombSearch"
        Me.GameLayout_UsernameLbl_BombSearch.Size = New System.Drawing.Size(183, 50)
        Me.GameLayout_UsernameLbl_BombSearch.TabIndex = 3
        Me.GameLayout_UsernameLbl_BombSearch.Text = "%username%"
        Me.GameLayout_UsernameLbl_BombSearch.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label8
        '
        Me.Label8.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Segoe UI", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label8.Location = New System.Drawing.Point(387, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(229, 50)
        Me.Label8.TabIndex = 4
        Me.Label8.Text = "Bomb Search"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GameLayout_Panel
        '
        Me.GameLayout_Panel.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.GameLayout_Panel.BackColor = System.Drawing.Color.Transparent
        Me.GameLayout_Panel.BackgroundImage = Global.CashClubCasino.My.Resources.Resources.dark_overlay
        Me.GameLayout_Panel.ColumnCount = 3
        Me.GameLayout_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.625669!))
        Me.GameLayout_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 90.37433!))
        Me.GameLayout_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 36.0!))
        Me.GameLayout_Panel.Controls.Add(Me.PictureBox2, 1, 1)
        Me.GameLayout_Panel.Controls.Add(Me.GameSelector_BombSearch, 1, 2)
        Me.GameLayout_Panel.Controls.Add(Me.Button2, 1, 3)
        Me.GameLayout_Panel.Controls.Add(Me.LogoutBtn_BombSearch, 1, 4)
        Me.GameLayout_Panel.Location = New System.Drawing.Point(4, -3)
        Me.GameLayout_Panel.Margin = New System.Windows.Forms.Padding(0)
        Me.GameLayout_Panel.Name = "GameLayout_Panel"
        Me.GameLayout_Panel.RowCount = 6
        Me.GameLayout_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.774799!))
        Me.GameLayout_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 92.2252!))
        Me.GameLayout_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 202.0!))
        Me.GameLayout_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 256.0!))
        Me.GameLayout_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.GameLayout_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29.0!))
        Me.GameLayout_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 51.0!))
        Me.GameLayout_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.GameLayout_Panel.Size = New System.Drawing.Size(243, 687)
        Me.GameLayout_Panel.TabIndex = 4
        '
        'PictureBox2
        '
        Me.PictureBox2.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.PictureBox2.BackgroundImage = Global.CashClubCasino.My.Resources.Resources.image_removebg_preview
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox2.Location = New System.Drawing.Point(29, 14)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(166, 117)
        Me.PictureBox2.TabIndex = 0
        Me.PictureBox2.TabStop = False
        '
        'GameSelector_BombSearch
        '
        Me.GameSelector_BombSearch.BackColor = System.Drawing.Color.Transparent
        Me.GameSelector_BombSearch.Controls.Add(Me.GameLayout_Selector_Slots)
        Me.GameSelector_BombSearch.Controls.Add(Me.GameLayout_Selector_BlackJack)
        Me.GameSelector_BombSearch.Controls.Add(Me.Label3)
        Me.GameSelector_BombSearch.Controls.Add(Me.GameLayout_Selector_Self_BombSearch)
        Me.GameSelector_BombSearch.Location = New System.Drawing.Point(22, 152)
        Me.GameSelector_BombSearch.Name = "GameSelector_BombSearch"
        Me.GameSelector_BombSearch.Size = New System.Drawing.Size(181, 194)
        Me.GameSelector_BombSearch.TabIndex = 2
        Me.GameSelector_BombSearch.TabStop = False
        '
        'GameLayout_Selector_Slots
        '
        Me.GameLayout_Selector_Slots.AutoSize = True
        Me.GameLayout_Selector_Slots.Font = New System.Drawing.Font("Segoe UI Semibold", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GameLayout_Selector_Slots.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GameLayout_Selector_Slots.Location = New System.Drawing.Point(6, 138)
        Me.GameLayout_Selector_Slots.Name = "GameLayout_Selector_Slots"
        Me.GameLayout_Selector_Slots.Size = New System.Drawing.Size(154, 34)
        Me.GameLayout_Selector_Slots.TabIndex = 3
        Me.GameLayout_Selector_Slots.TabStop = True
        Me.GameLayout_Selector_Slots.Text = "Slot Machine"
        Me.GameLayout_Selector_Slots.UseVisualStyleBackColor = True
        '
        'GameLayout_Selector_BlackJack
        '
        Me.GameLayout_Selector_BlackJack.AutoSize = True
        Me.GameLayout_Selector_BlackJack.Font = New System.Drawing.Font("Segoe UI Semibold", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GameLayout_Selector_BlackJack.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GameLayout_Selector_BlackJack.Location = New System.Drawing.Point(6, 98)
        Me.GameLayout_Selector_BlackJack.Name = "GameLayout_Selector_BlackJack"
        Me.GameLayout_Selector_BlackJack.Size = New System.Drawing.Size(127, 34)
        Me.GameLayout_Selector_BlackJack.TabIndex = 2
        Me.GameLayout_Selector_BlackJack.TabStop = True
        Me.GameLayout_Selector_BlackJack.Text = "Black Jack"
        Me.GameLayout_Selector_BlackJack.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label3.Location = New System.Drawing.Point(5, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(178, 32)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Game Selector"
        '
        'GameLayout_Selector_Self_BombSearch
        '
        Me.GameLayout_Selector_Self_BombSearch.AutoSize = True
        Me.GameLayout_Selector_Self_BombSearch.Checked = True
        Me.GameLayout_Selector_Self_BombSearch.Font = New System.Drawing.Font("Segoe UI Semibold", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GameLayout_Selector_Self_BombSearch.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GameLayout_Selector_Self_BombSearch.Location = New System.Drawing.Point(6, 58)
        Me.GameLayout_Selector_Self_BombSearch.Name = "GameLayout_Selector_Self_BombSearch"
        Me.GameLayout_Selector_Self_BombSearch.Size = New System.Drawing.Size(158, 34)
        Me.GameLayout_Selector_Self_BombSearch.TabIndex = 1
        Me.GameLayout_Selector_Self_BombSearch.TabStop = True
        Me.GameLayout_Selector_Self_BombSearch.Text = "Bomb Search"
        Me.GameLayout_Selector_Self_BombSearch.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button2.Font = New System.Drawing.Font("Segoe UI", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(22, 561)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(181, 43)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "Help"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'LogoutBtn_BombSearch
        '
        Me.LogoutBtn_BombSearch.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LogoutBtn_BombSearch.Font = New System.Drawing.Font("Segoe UI", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LogoutBtn_BombSearch.Location = New System.Drawing.Point(22, 610)
        Me.LogoutBtn_BombSearch.Name = "LogoutBtn_BombSearch"
        Me.LogoutBtn_BombSearch.Size = New System.Drawing.Size(181, 44)
        Me.LogoutBtn_BombSearch.TabIndex = 3
        Me.LogoutBtn_BombSearch.Text = "Logout"
        Me.LogoutBtn_BombSearch.UseVisualStyleBackColor = True
        '
        'BlackJackPage
        '
        Me.BlackJackPage.BackgroundImage = Global.CashClubCasino.My.Resources.Resources.casino_bg
        Me.BlackJackPage.Controls.Add(Me.TableLayoutPanel4)
        Me.BlackJackPage.Controls.Add(Me.TableLayoutPanel5)
        Me.BlackJackPage.Location = New System.Drawing.Point(4, 22)
        Me.BlackJackPage.Name = "BlackJackPage"
        Me.BlackJackPage.Size = New System.Drawing.Size(1272, 680)
        Me.BlackJackPage.TabIndex = 2
        Me.BlackJackPage.Text = "TabPage3"
        Me.BlackJackPage.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel4.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel4.BackgroundImage = Global.CashClubCasino.My.Resources.Resources.dark_overlay
        Me.TableLayoutPanel4.ColumnCount = 5
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 63.45776!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36.54224!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 137.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 126.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 143.0!))
        Me.TableLayoutPanel4.Controls.Add(Me.Label10, 3, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.GameLayout_BalanceLbl_BlackJack, 4, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.GameLayout_UsernameLbl_BlackJack, 0, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.Label7, 1, 0)
        Me.TableLayoutPanel4.Font = New System.Drawing.Font("Segoe UI", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TableLayoutPanel4.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(247, -3)
        Me.TableLayoutPanel4.Margin = New System.Windows.Forms.Padding(0)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 1
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(1021, 50)
        Me.TableLayoutPanel4.TabIndex = 9
        '
        'Label10
        '
        Me.Label10.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Segoe UI Semibold", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label10.Location = New System.Drawing.Point(780, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(94, 50)
        Me.Label10.TabIndex = 0
        Me.Label10.Text = "Balance:"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GameLayout_BalanceLbl_BlackJack
        '
        Me.GameLayout_BalanceLbl_BlackJack.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.GameLayout_BalanceLbl_BlackJack.AutoSize = True
        Me.GameLayout_BalanceLbl_BlackJack.Font = New System.Drawing.Font("Segoe UI Semibold", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GameLayout_BalanceLbl_BlackJack.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GameLayout_BalanceLbl_BlackJack.Location = New System.Drawing.Point(880, 0)
        Me.GameLayout_BalanceLbl_BlackJack.Name = "GameLayout_BalanceLbl_BlackJack"
        Me.GameLayout_BalanceLbl_BlackJack.Size = New System.Drawing.Size(66, 50)
        Me.GameLayout_BalanceLbl_BlackJack.TabIndex = 1
        Me.GameLayout_BalanceLbl_BlackJack.Text = "0.00$"
        Me.GameLayout_BalanceLbl_BlackJack.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'GameLayout_UsernameLbl_BlackJack
        '
        Me.GameLayout_UsernameLbl_BlackJack.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.GameLayout_UsernameLbl_BlackJack.AutoSize = True
        Me.GameLayout_UsernameLbl_BlackJack.Font = New System.Drawing.Font("Segoe UI Semibold", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GameLayout_UsernameLbl_BlackJack.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GameLayout_UsernameLbl_BlackJack.Location = New System.Drawing.Point(3, 0)
        Me.GameLayout_UsernameLbl_BlackJack.Name = "GameLayout_UsernameLbl_BlackJack"
        Me.GameLayout_UsernameLbl_BlackJack.Size = New System.Drawing.Size(183, 50)
        Me.GameLayout_UsernameLbl_BlackJack.TabIndex = 3
        Me.GameLayout_UsernameLbl_BlackJack.Text = "%username%"
        Me.GameLayout_UsernameLbl_BlackJack.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label7
        '
        Me.Label7.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(393, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(218, 50)
        Me.Label7.TabIndex = 4
        Me.Label7.Text = "Black Jack"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TableLayoutPanel5
        '
        Me.TableLayoutPanel5.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel5.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel5.BackgroundImage = Global.CashClubCasino.My.Resources.Resources.dark_overlay
        Me.TableLayoutPanel5.ColumnCount = 3
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.625669!))
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 90.37433!))
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 35.0!))
        Me.TableLayoutPanel5.Controls.Add(Me.PictureBox4, 1, 1)
        Me.TableLayoutPanel5.Controls.Add(Me.GameSelector_BlackJack, 1, 2)
        Me.TableLayoutPanel5.Controls.Add(Me.Button4, 1, 3)
        Me.TableLayoutPanel5.Controls.Add(Me.LogoutBtn_BlackJack, 1, 4)
        Me.TableLayoutPanel5.Location = New System.Drawing.Point(4, -3)
        Me.TableLayoutPanel5.Margin = New System.Windows.Forms.Padding(0)
        Me.TableLayoutPanel5.Name = "TableLayoutPanel5"
        Me.TableLayoutPanel5.RowCount = 6
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.774799!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 92.2252!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 202.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 256.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 51.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel5.Size = New System.Drawing.Size(243, 687)
        Me.TableLayoutPanel5.TabIndex = 8
        '
        'PictureBox4
        '
        Me.PictureBox4.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.PictureBox4.BackgroundImage = Global.CashClubCasino.My.Resources.Resources.image_removebg_preview
        Me.PictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox4.Location = New System.Drawing.Point(30, 14)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(166, 117)
        Me.PictureBox4.TabIndex = 0
        Me.PictureBox4.TabStop = False
        '
        'GameSelector_BlackJack
        '
        Me.GameSelector_BlackJack.BackColor = System.Drawing.Color.Transparent
        Me.GameSelector_BlackJack.Controls.Add(Me.GameLayout_Selector_SlotMachines_BlackJack)
        Me.GameSelector_BlackJack.Controls.Add(Me.GameLayout_Selector_Self_BlackJack)
        Me.GameSelector_BlackJack.Controls.Add(Me.Label13)
        Me.GameSelector_BlackJack.Controls.Add(Me.GameLayout_Selector_BombSearch_BlackJack)
        Me.GameSelector_BlackJack.Location = New System.Drawing.Point(23, 152)
        Me.GameSelector_BlackJack.Name = "GameSelector_BlackJack"
        Me.GameSelector_BlackJack.Size = New System.Drawing.Size(181, 194)
        Me.GameSelector_BlackJack.TabIndex = 2
        Me.GameSelector_BlackJack.TabStop = False
        '
        'GameLayout_Selector_SlotMachines_BlackJack
        '
        Me.GameLayout_Selector_SlotMachines_BlackJack.AutoSize = True
        Me.GameLayout_Selector_SlotMachines_BlackJack.Font = New System.Drawing.Font("Segoe UI Semibold", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GameLayout_Selector_SlotMachines_BlackJack.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GameLayout_Selector_SlotMachines_BlackJack.Location = New System.Drawing.Point(6, 138)
        Me.GameLayout_Selector_SlotMachines_BlackJack.Name = "GameLayout_Selector_SlotMachines_BlackJack"
        Me.GameLayout_Selector_SlotMachines_BlackJack.Size = New System.Drawing.Size(154, 34)
        Me.GameLayout_Selector_SlotMachines_BlackJack.TabIndex = 3
        Me.GameLayout_Selector_SlotMachines_BlackJack.TabStop = True
        Me.GameLayout_Selector_SlotMachines_BlackJack.Text = "Slot Machine"
        Me.GameLayout_Selector_SlotMachines_BlackJack.UseVisualStyleBackColor = True
        '
        'GameLayout_Selector_Self_BlackJack
        '
        Me.GameLayout_Selector_Self_BlackJack.AutoSize = True
        Me.GameLayout_Selector_Self_BlackJack.Checked = True
        Me.GameLayout_Selector_Self_BlackJack.Font = New System.Drawing.Font("Segoe UI Semibold", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GameLayout_Selector_Self_BlackJack.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GameLayout_Selector_Self_BlackJack.Location = New System.Drawing.Point(6, 98)
        Me.GameLayout_Selector_Self_BlackJack.Name = "GameLayout_Selector_Self_BlackJack"
        Me.GameLayout_Selector_Self_BlackJack.Size = New System.Drawing.Size(127, 34)
        Me.GameLayout_Selector_Self_BlackJack.TabIndex = 2
        Me.GameLayout_Selector_Self_BlackJack.TabStop = True
        Me.GameLayout_Selector_Self_BlackJack.Text = "Black Jack"
        Me.GameLayout_Selector_Self_BlackJack.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label13.Location = New System.Drawing.Point(5, 16)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(178, 32)
        Me.Label13.TabIndex = 3
        Me.Label13.Text = "Game Selector"
        '
        'GameLayout_Selector_BombSearch_BlackJack
        '
        Me.GameLayout_Selector_BombSearch_BlackJack.AutoSize = True
        Me.GameLayout_Selector_BombSearch_BlackJack.Font = New System.Drawing.Font("Segoe UI Semibold", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GameLayout_Selector_BombSearch_BlackJack.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GameLayout_Selector_BombSearch_BlackJack.Location = New System.Drawing.Point(6, 58)
        Me.GameLayout_Selector_BombSearch_BlackJack.Name = "GameLayout_Selector_BombSearch_BlackJack"
        Me.GameLayout_Selector_BombSearch_BlackJack.Size = New System.Drawing.Size(158, 34)
        Me.GameLayout_Selector_BombSearch_BlackJack.TabIndex = 1
        Me.GameLayout_Selector_BombSearch_BlackJack.Text = "Bomb Search"
        Me.GameLayout_Selector_BombSearch_BlackJack.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button4.Font = New System.Drawing.Font("Segoe UI", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(23, 561)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(181, 43)
        Me.Button4.TabIndex = 4
        Me.Button4.Text = "Help"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'LogoutBtn_BlackJack
        '
        Me.LogoutBtn_BlackJack.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LogoutBtn_BlackJack.Font = New System.Drawing.Font("Segoe UI", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LogoutBtn_BlackJack.Location = New System.Drawing.Point(23, 610)
        Me.LogoutBtn_BlackJack.Name = "LogoutBtn_BlackJack"
        Me.LogoutBtn_BlackJack.Size = New System.Drawing.Size(181, 44)
        Me.LogoutBtn_BlackJack.TabIndex = 3
        Me.LogoutBtn_BlackJack.Text = "Logout"
        Me.LogoutBtn_BlackJack.UseVisualStyleBackColor = True
        '
        'SlotMachinesPage
        '
        Me.SlotMachinesPage.BackgroundImage = Global.CashClubCasino.My.Resources.Resources.casino_bg
        Me.SlotMachinesPage.Controls.Add(Me.TableLayoutPanel2)
        Me.SlotMachinesPage.Controls.Add(Me.TableLayoutPanel3)
        Me.SlotMachinesPage.Location = New System.Drawing.Point(4, 22)
        Me.SlotMachinesPage.Name = "SlotMachinesPage"
        Me.SlotMachinesPage.Size = New System.Drawing.Size(1272, 680)
        Me.SlotMachinesPage.TabIndex = 3
        Me.SlotMachinesPage.Text = "TabPage3"
        Me.SlotMachinesPage.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel2.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel2.BackgroundImage = Global.CashClubCasino.My.Resources.Resources.dark_overlay
        Me.TableLayoutPanel2.ColumnCount = 5
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 65.63574!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34.36426!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 146.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 126.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 143.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.Label6, 3, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.GameLayout_BalanceLbl_SlotMachines, 4, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.GameLayout_UsernameLbl_SlotMachines, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Label11, 1, 0)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(247, -3)
        Me.TableLayoutPanel2.Margin = New System.Windows.Forms.Padding(0)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(1021, 50)
        Me.TableLayoutPanel2.TabIndex = 7
        '
        'Label6
        '
        Me.Label6.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI Semibold", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label6.Location = New System.Drawing.Point(780, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(94, 50)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Balance:"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GameLayout_BalanceLbl_SlotMachines
        '
        Me.GameLayout_BalanceLbl_SlotMachines.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.GameLayout_BalanceLbl_SlotMachines.AutoSize = True
        Me.GameLayout_BalanceLbl_SlotMachines.Font = New System.Drawing.Font("Segoe UI Semibold", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GameLayout_BalanceLbl_SlotMachines.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GameLayout_BalanceLbl_SlotMachines.Location = New System.Drawing.Point(880, 0)
        Me.GameLayout_BalanceLbl_SlotMachines.Name = "GameLayout_BalanceLbl_SlotMachines"
        Me.GameLayout_BalanceLbl_SlotMachines.Size = New System.Drawing.Size(66, 50)
        Me.GameLayout_BalanceLbl_SlotMachines.TabIndex = 1
        Me.GameLayout_BalanceLbl_SlotMachines.Text = "0.00$"
        Me.GameLayout_BalanceLbl_SlotMachines.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'GameLayout_UsernameLbl_SlotMachines
        '
        Me.GameLayout_UsernameLbl_SlotMachines.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.GameLayout_UsernameLbl_SlotMachines.AutoSize = True
        Me.GameLayout_UsernameLbl_SlotMachines.Font = New System.Drawing.Font("Segoe UI Semibold", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GameLayout_UsernameLbl_SlotMachines.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GameLayout_UsernameLbl_SlotMachines.Location = New System.Drawing.Point(3, 0)
        Me.GameLayout_UsernameLbl_SlotMachines.Name = "GameLayout_UsernameLbl_SlotMachines"
        Me.GameLayout_UsernameLbl_SlotMachines.Size = New System.Drawing.Size(183, 50)
        Me.GameLayout_UsernameLbl_SlotMachines.TabIndex = 3
        Me.GameLayout_UsernameLbl_SlotMachines.Text = "%username%"
        Me.GameLayout_UsernameLbl_SlotMachines.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label11
        '
        Me.Label11.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Segoe UI", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label11.Location = New System.Drawing.Point(400, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(202, 50)
        Me.Label11.TabIndex = 4
        Me.Label11.Text = "Slot Machine"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel3.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel3.BackgroundImage = Global.CashClubCasino.My.Resources.Resources.dark_overlay
        Me.TableLayoutPanel3.ColumnCount = 3
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.625669!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 90.37433!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.TableLayoutPanel3.Controls.Add(Me.PictureBox3, 1, 1)
        Me.TableLayoutPanel3.Controls.Add(Me.GameSelector_SlotMachines, 1, 2)
        Me.TableLayoutPanel3.Controls.Add(Me.Button1, 1, 3)
        Me.TableLayoutPanel3.Controls.Add(Me.LogoutBtn_SlotMachines, 1, 4)
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(4, -3)
        Me.TableLayoutPanel3.Margin = New System.Windows.Forms.Padding(0)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 6
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.774799!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 92.2252!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 202.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 256.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 51.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(243, 687)
        Me.TableLayoutPanel3.TabIndex = 6
        '
        'PictureBox3
        '
        Me.PictureBox3.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.PictureBox3.BackgroundImage = Global.CashClubCasino.My.Resources.Resources.image_removebg_preview
        Me.PictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox3.Location = New System.Drawing.Point(32, 14)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(166, 117)
        Me.PictureBox3.TabIndex = 0
        Me.PictureBox3.TabStop = False
        '
        'GameSelector_SlotMachines
        '
        Me.GameSelector_SlotMachines.BackColor = System.Drawing.Color.Transparent
        Me.GameSelector_SlotMachines.Controls.Add(Me.GameLayout_Selector_Self_SlotMachines)
        Me.GameSelector_SlotMachines.Controls.Add(Me.GameLayout_Selector_BlackJack_SlotMachines)
        Me.GameSelector_SlotMachines.Controls.Add(Me.Label9)
        Me.GameSelector_SlotMachines.Controls.Add(Me.GameLayout_Selector_BombSearch_SlotMachines)
        Me.GameSelector_SlotMachines.Location = New System.Drawing.Point(23, 152)
        Me.GameSelector_SlotMachines.Name = "GameSelector_SlotMachines"
        Me.GameSelector_SlotMachines.Size = New System.Drawing.Size(184, 194)
        Me.GameSelector_SlotMachines.TabIndex = 2
        Me.GameSelector_SlotMachines.TabStop = False
        '
        'GameLayout_Selector_Self_SlotMachines
        '
        Me.GameLayout_Selector_Self_SlotMachines.AutoSize = True
        Me.GameLayout_Selector_Self_SlotMachines.Checked = True
        Me.GameLayout_Selector_Self_SlotMachines.Font = New System.Drawing.Font("Segoe UI Semibold", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GameLayout_Selector_Self_SlotMachines.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GameLayout_Selector_Self_SlotMachines.Location = New System.Drawing.Point(6, 138)
        Me.GameLayout_Selector_Self_SlotMachines.Name = "GameLayout_Selector_Self_SlotMachines"
        Me.GameLayout_Selector_Self_SlotMachines.Size = New System.Drawing.Size(154, 34)
        Me.GameLayout_Selector_Self_SlotMachines.TabIndex = 3
        Me.GameLayout_Selector_Self_SlotMachines.TabStop = True
        Me.GameLayout_Selector_Self_SlotMachines.Text = "Slot Machine"
        Me.GameLayout_Selector_Self_SlotMachines.UseVisualStyleBackColor = True
        '
        'GameLayout_Selector_BlackJack_SlotMachines
        '
        Me.GameLayout_Selector_BlackJack_SlotMachines.AutoSize = True
        Me.GameLayout_Selector_BlackJack_SlotMachines.Font = New System.Drawing.Font("Segoe UI Semibold", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GameLayout_Selector_BlackJack_SlotMachines.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GameLayout_Selector_BlackJack_SlotMachines.Location = New System.Drawing.Point(6, 98)
        Me.GameLayout_Selector_BlackJack_SlotMachines.Name = "GameLayout_Selector_BlackJack_SlotMachines"
        Me.GameLayout_Selector_BlackJack_SlotMachines.Size = New System.Drawing.Size(127, 34)
        Me.GameLayout_Selector_BlackJack_SlotMachines.TabIndex = 2
        Me.GameLayout_Selector_BlackJack_SlotMachines.Text = "Black Jack"
        Me.GameLayout_Selector_BlackJack_SlotMachines.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label9.Location = New System.Drawing.Point(5, 16)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(178, 32)
        Me.Label9.TabIndex = 3
        Me.Label9.Text = "Game Selector"
        '
        'GameLayout_Selector_BombSearch_SlotMachines
        '
        Me.GameLayout_Selector_BombSearch_SlotMachines.AutoSize = True
        Me.GameLayout_Selector_BombSearch_SlotMachines.Font = New System.Drawing.Font("Segoe UI Semibold", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GameLayout_Selector_BombSearch_SlotMachines.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GameLayout_Selector_BombSearch_SlotMachines.Location = New System.Drawing.Point(6, 58)
        Me.GameLayout_Selector_BombSearch_SlotMachines.Name = "GameLayout_Selector_BombSearch_SlotMachines"
        Me.GameLayout_Selector_BombSearch_SlotMachines.Size = New System.Drawing.Size(158, 34)
        Me.GameLayout_Selector_BombSearch_SlotMachines.TabIndex = 1
        Me.GameLayout_Selector_BombSearch_SlotMachines.Text = "Bomb Search"
        Me.GameLayout_Selector_BombSearch_SlotMachines.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button1.Font = New System.Drawing.Font("Segoe UI", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(23, 561)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(184, 43)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "Help"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'LogoutBtn_SlotMachines
        '
        Me.LogoutBtn_SlotMachines.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LogoutBtn_SlotMachines.Font = New System.Drawing.Font("Segoe UI", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LogoutBtn_SlotMachines.Location = New System.Drawing.Point(23, 610)
        Me.LogoutBtn_SlotMachines.Name = "LogoutBtn_SlotMachines"
        Me.LogoutBtn_SlotMachines.Size = New System.Drawing.Size(184, 44)
        Me.LogoutBtn_SlotMachines.TabIndex = 3
        Me.LogoutBtn_SlotMachines.Text = "Logout"
        Me.LogoutBtn_SlotMachines.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1264, 681)
        Me.Controls.Add(Me.Controller)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.Controller.ResumeLayout(False)
        Me.StartPage.ResumeLayout(False)
        Me.LoginMenuPanel.ResumeLayout(False)
        Me.LoginMenuPanel.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LoginMenu_AgeNum, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.BombSearchPage.ResumeLayout(False)
        Me.GameLayout_Nav.ResumeLayout(False)
        Me.GameLayout_Nav.PerformLayout()
        Me.GameLayout_Panel.ResumeLayout(False)
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GameSelector_BombSearch.ResumeLayout(False)
        Me.GameSelector_BombSearch.PerformLayout()
        Me.BlackJackPage.ResumeLayout(False)
        Me.TableLayoutPanel4.ResumeLayout(False)
        Me.TableLayoutPanel4.PerformLayout()
        Me.TableLayoutPanel5.ResumeLayout(False)
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GameSelector_BlackJack.ResumeLayout(False)
        Me.GameSelector_BlackJack.PerformLayout()
        Me.SlotMachinesPage.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        Me.TableLayoutPanel3.ResumeLayout(False)
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GameSelector_SlotMachines.ResumeLayout(False)
        Me.GameSelector_SlotMachines.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Controller As TabControl
    Friend WithEvents StartPage As TabPage
    Friend WithEvents BombSearchPage As TabPage
    Friend WithEvents BlackJackPage As TabPage
    Friend WithEvents SlotMachinesPage As TabPage
    Friend WithEvents GameLayout_Nav As TableLayoutPanel
    Friend WithEvents Label5 As Label
    Friend WithEvents GameLayout_BalanceLbl_BombSearch As Label
    Friend WithEvents GameLayout_UsernameLbl_BombSearch As Label
    Friend WithEvents GameLayout_Panel As TableLayoutPanel
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents GameSelector_BombSearch As GroupBox
    Friend WithEvents GameLayout_Selector_Slots As RadioButton
    Friend WithEvents GameLayout_Selector_BlackJack As RadioButton
    Friend WithEvents Label3 As Label
    Friend WithEvents GameLayout_Selector_Self_BombSearch As RadioButton
    Friend WithEvents Button2 As Button
    Friend WithEvents LogoutBtn_BombSearch As Button
    Friend WithEvents LoginMenuPanel As TableLayoutPanel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents LoginMenu_QuitBtn As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents LoginMenu_NameTxt As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents LoginMenu_AgeNum As NumericUpDown
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents LoginMenu_plus1000Btn As Button
    Friend WithEvents LoginMenu_plus100Btn As Button
    Friend WithEvents LoginMenu_min100Btn As Button
    Friend WithEvents LoginMenu_min1000Btn As Button
    Friend WithEvents LoginMenu_CapitalLbl As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents LoginMenu_LoginBtn As Button
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents Label6 As Label
    Friend WithEvents GameLayout_BalanceLbl_SlotMachines As Label
    Friend WithEvents GameLayout_UsernameLbl_SlotMachines As Label
    Friend WithEvents TableLayoutPanel3 As TableLayoutPanel
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents GameSelector_SlotMachines As GroupBox
    Friend WithEvents GameLayout_Selector_Self_SlotMachines As RadioButton
    Friend WithEvents GameLayout_Selector_BlackJack_SlotMachines As RadioButton
    Friend WithEvents Label9 As Label
    Friend WithEvents GameLayout_Selector_BombSearch_SlotMachines As RadioButton
    Friend WithEvents Button1 As Button
    Friend WithEvents LogoutBtn_SlotMachines As Button
    Friend WithEvents TableLayoutPanel4 As TableLayoutPanel
    Friend WithEvents Label10 As Label
    Friend WithEvents GameLayout_BalanceLbl_BlackJack As Label
    Friend WithEvents GameLayout_UsernameLbl_BlackJack As Label
    Friend WithEvents TableLayoutPanel5 As TableLayoutPanel
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents GameSelector_BlackJack As GroupBox
    Friend WithEvents GameLayout_Selector_SlotMachines_BlackJack As RadioButton
    Friend WithEvents GameLayout_Selector_Self_BlackJack As RadioButton
    Friend WithEvents Label13 As Label
    Friend WithEvents GameLayout_Selector_BombSearch_BlackJack As RadioButton
    Friend WithEvents Button4 As Button
    Friend WithEvents LogoutBtn_BlackJack As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label11 As Label
End Class
