﻿Public Class Form1
    Dim player As Player
    Dim welcomeUserLabels As Label()  '// list of labels
    Dim balanceLabels As Label()
    Dim gameSelectors As List(Of List(Of RadioButton)) ' // 0: BombSearchBtns, 1: BlackJackBtns, 2: SlotMachinesBtns
    Dim logoutButtons As Button()

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        welcomeUserLabels = New Label() {
            GameLayout_UsernameLbl_BombSearch,
            GameLayout_UsernameLbl_BlackJack,
            GameLayout_UsernameLbl_SlotMachines
        }

        balanceLabels = New Label() {
            GameLayout_BalanceLbl_BombSearch,
            GameLayout_BalanceLbl_BlackJack,
            GameLayout_BalanceLbl_SlotMachines
        }

        Dim temp_group_list As List(Of GroupBox)
        temp_group_list = New List(Of GroupBox) From {
            GameSelector_BombSearch,
            GameSelector_BlackJack,
            GameSelector_SlotMachines
        }

        LoadStart()


    End Sub

    ' // Page Loading //
    Private Sub LoadStart()
        Controller.SelectedTab = StartPage
    End Sub
    Private Sub LoadBombSearcher()
        Controller.SelectedTab = BombSearchPage
        BombSearch_Load()
    End Sub
    Private Sub LoadBlackJack()
        Controller.SelectedTab = BlackJackPage
        BlackJack_Load()
    End Sub
    Private Sub LoadSlotMachines()
        Controller.SelectedTab = SlotMachinesPage
        SlotMachines_Load()
    End Sub

    ' // ################################# [START PAGE] #################################
    ' // Start Page Button Handling
    Private Sub LoginMenu_LoginBtn_Click(sender As Object, e As EventArgs) Handles LoginMenu_LoginBtn.Click
        ' // conditions: player.age > 18, player.name.Length > 2, player.balance != 0
        player = New Player With {
            .age = LoginMenu_AgeNum.Value,
            .balance = LoginMenu_CapitalLbl.Text.Replace("$", ""),
            .game = Game.BombSearch, ' // First game 
            .name = LoginMenu_NameTxt.Text
        }
        If player.age < 18 Then
            MsgBox("Sorry, you must be at least 18 years old to access this content." & vbCrLf & "Please come back when you are of legal age.")
            Return
        ElseIf player.name.Length < 3 Then
            MsgBox("The username you entered is too short. Usernames must be at least 3 characters long." & vbCrLf & "Please enter a longer username to continue.")
            Return
        ElseIf player.balance = 0 Then
            MsgBox("We're sorry, but your deposit amount does not meet the minimum requirement of $100." & vbCrLf & "Please deposit at least $100 to continue." & vbCrLf & "Thank you for your understanding!")
            Return
        End If

        LoadBombSearcher()
    End Sub

    Private Sub LoginMenu_QuitBtn_Click(sender As Object, e As EventArgs) Handles LoginMenu_QuitBtn.Click
        Me.Close()
    End Sub

    Private Sub UpdateLoginMenuBalance(value As Double)
        Dim setBalance As String
        setBalance = LoginMenu_CapitalLbl.Text.Replace("$", "")
        If setBalance + value >= 0 Then
            LoginMenu_CapitalLbl.Text = setBalance + value & "$"
        End If
    End Sub

    Private Sub LoginMenu_plus1000Btn_Click(sender As Object, e As EventArgs) Handles LoginMenu_plus1000Btn.Click
        UpdateLoginMenuBalance(1000)
    End Sub

    Private Sub LoginMenu_plus100Btn_Click(sender As Object, e As EventArgs) Handles LoginMenu_plus100Btn.Click
        UpdateLoginMenuBalance(100)
    End Sub

    Private Sub LoginMenu_min100Btn_Click(sender As Object, e As EventArgs) Handles LoginMenu_min100Btn.Click
        UpdateLoginMenuBalance(-100)
    End Sub

    Private Sub LoginMenu_min1000Btn_Click(sender As Object, e As EventArgs) Handles LoginMenu_min1000Btn.Click
        UpdateLoginMenuBalance(-1000)
    End Sub



    ' // ################################# [COMMON GAME] #################################
    Private Sub Logout()
        player = New Player With {
            .balance = 0,
            .name = "",
            .age = 0,
            .game = Game.BombSearch
        }
        LoginMenu_AgeNum.Value = player.age
        LoginMenu_CapitalLbl.Text = player.balance & "$"
        LoginMenu_NameTxt.Text = player.name

        LoadStart()
    End Sub

    Private Sub SetGameMode(game As Game)
        player.game = game

        Select Case game
            Case Game.BombSearch
                LoadBombSearcher()
            Case Game.BlackJack
                LoadBlackJack()
            Case Game.SlotMachines
                LoadSlotMachines()
        End Select
        GameLayout_Selector_Self_BombSearch.Checked = True
        GameLayout_Selector_Self_BlackJack.Checked = True
        GameLayout_Selector_Self_SlotMachines.Checked = True

    End Sub



    ' // ################################# [BOMBSEARCHER] ################################
    ' // Game Selector
    Private Sub GameLayout_Selector_BlackJack_CheckedChanged(sender As Object, e As EventArgs) Handles GameLayout_Selector_BlackJack.CheckedChanged

        If GameLayout_Selector_BlackJack.Checked Then
            SetGameMode(Game.BlackJack)
        End If

    End Sub
    Private Sub GameLayout_Selector_Slots_CheckedChanged(sender As Object, e As EventArgs) Handles GameLayout_Selector_Slots.CheckedChanged

        If GameLayout_Selector_Slots.Checked Then
            SetGameMode(Game.SlotMachines)
        End If
    End Sub

    Private Sub LogoutBtn_BombSearch_Click(sender As Object, e As EventArgs) Handles LogoutBtn_BombSearch.Click
        Logout()
    End Sub

    Private Sub BombSearch_Load()

    End Sub




    ' // ################################## [BLACKJACK] ##################################
    ' // Game Selector
    Private Sub GameLayout_Selector_BombSearch_BlackJack_CheckedChanged(sender As Object, e As EventArgs) Handles GameLayout_Selector_BombSearch_BlackJack.CheckedChanged

        If GameLayout_Selector_BombSearch_BlackJack.Checked Then
            SetGameMode(Game.BombSearch)
        End If

    End Sub
    Private Sub GameLayout_Selector_SlotMachines_BlackJack_CheckedChanged(sender As Object, e As EventArgs) Handles GameLayout_Selector_SlotMachines_BlackJack.CheckedChanged

        If GameLayout_Selector_SlotMachines_BlackJack.Checked Then
            SetGameMode(Game.SlotMachines)
        End If
    End Sub

    Private Sub LogoutBtn_BlackJack_Click(sender As Object, e As EventArgs) Handles LogoutBtn_BlackJack.Click
        Logout()
    End Sub


    ' // Vanaf Hier kunt ge doen wat ge wilt
    Private Sub BlackJack_Load()
        ' // Deze functie wordt opgeroepen zodra het spel wordt ingeladen
        ' // Je kan da dus vergelijken met de standaard Form1_Load() functie die ge altijd hebt maar dan voor uw spel
        ' // Wanneer ge in de editor zijt kunt ge normaal gezien rechts boven u "properties" van tab veranderen
        ' // De verschillende nuttig Tabs zijn: BlackJackPage, BombSearchPage, SlotMachinesPage
        ' // Zorg dus dat je op de juiste pagina zit voordat ge iets veranderd!


    End Sub

    ' // Tot hier


    ' // ################################# [SLOTMACHINES] ################################
    ' // Game Selector
    Private Sub GameLayout_Selector_BombSearch_SlotMachines_CheckedChanged(sender As Object, e As EventArgs) Handles GameLayout_Selector_BombSearch_SlotMachines.CheckedChanged

        If GameLayout_Selector_BombSearch_SlotMachines.Checked Then
            SetGameMode(Game.BombSearch)
        End If
    End Sub
    Private Sub GameLayout_Selector_BlackJack_SlotMachines_CheckedChanged(sender As Object, e As EventArgs) Handles GameLayout_Selector_BlackJack_SlotMachines.CheckedChanged

        If GameLayout_Selector_BlackJack_SlotMachines.Checked Then
            SetGameMode(Game.BlackJack)
        End If
    End Sub

    Private Sub LogoutBtn_SlotMachines_Click(sender As Object, e As EventArgs) Handles LogoutBtn_SlotMachines.Click
        Logout()
    End Sub

    ' // Vanaf Hier kunt ge doen wat ge wilt
    Private Sub SlotMachines_Load()
        '// Deze functie wordt opgeroepen zodra het spel wordt ingeladen
        ' // Je kan da dus vergelijken met de standaard Form1_Load() functie die ge altijd hebt maar dan voor uw spel
        ' // Wanneer ge in de editor zijt kunt ge normaal gezien rechts boven u "properties" van tab veranderen
        ' // De verschillende nuttig Tabs zijn: BlackJackPage, BombSearchPage, SlotMachinesPage
        ' // Zorg dus dat je op de juiste pagina zit voordat ge iets veranderd!


    End Sub

    ' // Tot hier

End Class

Enum Game
    BombSearch
    BlackJack
    SlotMachines
End Enum
Structure Player
    Public balance As Double
    Public age As Integer
    Public name As String
    Public game As Game
End Structure
